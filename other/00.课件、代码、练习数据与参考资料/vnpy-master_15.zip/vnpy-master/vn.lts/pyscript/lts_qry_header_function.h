int reqUserLogin(dict req, int nRequestID);

int reqUserLogout(dict req, int nRequestID);

int reqFetchAuthRandCode(dict req, int nRequestID);

int reqQryExchange(dict req, int nRequestID);

int reqQryInstrument(dict req, int nRequestID);

int reqQryInvestor(dict req, int nRequestID);

int reqQryTradingCode(dict req, int nRequestID);

int reqQryTradingAccount(dict req, int nRequestID);

int reqQryBondInterest(dict req, int nRequestID);

int reqQryMarketRationInfo(dict req, int nRequestID);

int reqQryInstrumentCommissionRate(dict req, int nRequestID);

int reqQryETFInstrument(dict req, int nRequestID);

int reqQryETFBasket(dict req, int nRequestID);

int reqQryOFInstrument(dict req, int nRequestID);

int reqQrySFInstrument(dict req, int nRequestID);

int reqQryInstrumentUnitMargin(dict req, int nRequestID);

int reqQryPreDelivInfo(dict req, int nRequestID);

int reqQryCreditStockAssignInfo(dict req, int nRequestID);

int reqQryCreditCashAssignInfo(dict req, int nRequestID);

int reqQryConversionRate(dict req, int nRequestID);

int reqQryHisCreditDebtInfo(dict req, int nRequestID);

int reqQryMarketDataStaticInfo(dict req, int nRequestID);

int reqQryExpireRepurchInfo(dict req, int nRequestID);

int reqQryBondPledgeRate(dict req, int nRequestID);

int reqQryPledgeBond(dict req, int nRequestID);

int reqQryOrder(dict req, int nRequestID);

int reqQryTrade(dict req, int nRequestID);

int reqQryInvestorPosition(dict req, int nRequestID);

int reqQryFundTransferSerial(dict req, int nRequestID);

int reqQryFundInterTransferSerial(dict req, int nRequestID);

