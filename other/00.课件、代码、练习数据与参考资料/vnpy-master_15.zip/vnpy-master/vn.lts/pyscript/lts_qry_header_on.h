


virtual void onRspError(dict error, int id, bool last) {};

virtual void onRspUserLogin(dict data, dict error, int id, bool last) {};

virtual void onRspUserLogout(dict data, dict error, int id, bool last) {};

virtual void onRspFetchAuthRandCode(dict data, dict error, int id, bool last) {};

virtual void onRspQryExchange(dict data, dict error, int id, bool last) {};

virtual void onRspQryInstrument(dict data, dict error, int id, bool last) {};

virtual void onRspQryInvestor(dict data, dict error, int id, bool last) {};

virtual void onRspQryTradingCode(dict data, dict error, int id, bool last) {};

virtual void onRspQryTradingAccount(dict data, dict error, int id, bool last) {};

virtual void onRspQryBondInterest(dict data, dict error, int id, bool last) {};

virtual void onRspQryMarketRationInfo(dict data, dict error, int id, bool last) {};

virtual void onRspQryInstrumentCommissionRate(dict data, dict error, int id, bool last) {};

virtual void onRspQryETFInstrument(dict data, dict error, int id, bool last) {};

virtual void onRspQryETFBasket(dict data, dict error, int id, bool last) {};

virtual void onRspQryOFInstrument(dict data, dict error, int id, bool last) {};

virtual void onRspQrySFInstrument(dict data, dict error, int id, bool last) {};

virtual void onRspQryInstrumentUnitMargin(dict data, dict error, int id, bool last) {};

virtual void onRspQryPreDelivInfo(dict data, dict error, int id, bool last) {};

virtual void onRspQryCreditStockAssignInfo(dict data, dict error, int id, bool last) {};

virtual void onRspQryCreditCashAssignInfo(dict data, dict error, int id, bool last) {};

virtual void onRspQryConversionRate(dict data, dict error, int id, bool last) {};

virtual void onRspQryHisCreditDebtInfo(dict data, dict error, int id, bool last) {};

virtual void onRspQryMarketDataStaticInfo(dict data, dict error, int id, bool last) {};

virtual void onRspQryExpireRepurchInfo(dict data, dict error, int id, bool last) {};

virtual void onRspQryBondPledgeRate(dict data, dict error, int id, bool last) {};

virtual void onRspQryPledgeBond(dict data, dict error, int id, bool last) {};

virtual void onRspQryOrder(dict data, dict error, int id, bool last) {};

virtual void onRspQryTrade(dict data, dict error, int id, bool last) {};

virtual void onRspQryInvestorPosition(dict data, dict error, int id, bool last) {};

virtual void onRspQryFundTransferSerial(dict data, dict error, int id, bool last) {};

virtual void onRspQryFundInterTransferSerial(dict data, dict error, int id, bool last) {};

