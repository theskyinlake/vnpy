int reqUserLogin(dict req);

int reqUserLogout(dict req);

int reqInsertOrder(dict req);

int reqCancelOrder(dict req);

int reqQryPosition(dict req);

int reqQryCustomerCapital(dict req);

int reqQryExchangeInstrument(dict req);

int reqQryArbitrageInstrument(dict req);

int reqQryOrderInfo(dict req);

int reqQryMatchInfo(dict req);

int reqQrySpecifyInstrument(dict req);

int reqQryPositionDetail(dict req);

int reqConfirmProductInfo(dict req);

int reqResetPassword (dict req);

int reqBillConfirm(dict req);

int reqQryTradeCode(dict req);

int reqEquityComputMode(dict req);

int reqQryBill(dict req);

int reqTradingDay(dict req);

int reqQryQuoteNotice(dict req);

int reqQuoteInsert(dict req);

int reqQuoteCancel(dict req);

int reqCancelAllOrder(dict req);

int reqForQuote(dict req);

int reqQryForQuote(dict req);

int reqQryQuoteOrderInfo(dict req);

int reqQryTransferBank(dict req);

int reqQryTransferSerial(dict req);

int reqFromBankToFutureByFuture(dict req);

int reqFromFutureToBankByFuture(dict req);

int reqQryExchangeStatus(dict req);

int reqQryDepthMarketData(dict req);

