int reqUserLogin(dict req, int nRequestID);

int reqUserLogout(dict req, int nRequestID);

