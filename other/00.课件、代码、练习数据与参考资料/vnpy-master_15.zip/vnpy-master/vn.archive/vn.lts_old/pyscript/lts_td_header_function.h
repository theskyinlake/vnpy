int reqUserLogin(dict req, int nRequestID);

int reqUserLogout(dict req, int nRequestID);

int reqOrderInsert(dict req, int nRequestID);

int reqOrderAction(dict req, int nRequestID);

int reqUserPasswordUpdate(dict req, int nRequestID);

int reqTradingAccountPasswordUpdate(dict req, int nRequestID);

int reqQryExchange(dict req, int nRequestID);

int reqQryInstrument(dict req, int nRequestID);

int reqQryInvestor(dict req, int nRequestID);

int reqQryTradingCode(dict req, int nRequestID);

int reqQryTradingAccount(dict req, int nRequestID);

int reqQryDepthMarketData(dict req, int nRequestID);

int reqQryBondInterest(dict req, int nRequestID);

int reqQryMarketRationInfo(dict req, int nRequestID);

int reqQryInstrumentCommissionRate(dict req, int nRequestID);

int reqQryETFInstrument(dict req, int nRequestID);

int reqQryETFBasket(dict req, int nRequestID);

int reqQryOFInstrument(dict req, int nRequestID);

int reqQrySFInstrument(dict req, int nRequestID);

int reqQryOrder(dict req, int nRequestID);

int reqQryTrade(dict req, int nRequestID);

int reqQryInvestorPosition(dict req, int nRequestID);

int reqFundOutByLiber(dict req, int nRequestID);

int reqQryFundTransferSerial(dict req, int nRequestID);

int reqFundInterTransfer(dict req, int nRequestID);

int reqQryFundInterTransferSerial(dict req, int nRequestID);

