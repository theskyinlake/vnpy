#ifndef _LTS_NAMESPACE_H
#define _LTS_NAMESPACE_H

#define _LTS_NS_	_LTS_
#define _LTS_NS_BEGIN_ namespace _LTS_{
#define _LTS_NS_END_	}
#define _USING_LTS_NS_	using namespace _LTS_;

#endif
