# strategydemo说明

该文件夹下：

- demoStrategy包含了一个简单的双EMA均线交易策略，填入账号密码等资料后可直接运行
- demoBacktesting包含了一个基于以上策略的回测脚本，结果会输出到"result.vn"二进制文件中，可以使用Python的shelve模块打开