int reqUserLogin(dict req, int nRequestID);

int reqUserLogout(dict req, int nRequestID);

int reqUserReLogin(dict req, int nRequestID);

int reqQryInstrument(dict req, int nRequestID);

int reqOrderInsert(dict req, int nRequestID);

int reqOrderAction(dict req, int nRequestID);

int reqQryInvestorPosition(dict req, int nRequestID);

int reqQryTradingAccount(dict req, int nRequestID);

int reqQryTrade(dict req, int nRequestID);

int reqQryOrder(dict req, int nRequestID);

int reqQryStorage(dict req, int nRequestID);

