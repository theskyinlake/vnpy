void processFrontConnected(Task task);

void processFrontDisconnected(Task task);

void processRspUserLogin(Task task);

void processRspUserLogout(Task task);

void processRtnDepthMarketData(Task task);

