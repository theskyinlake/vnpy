int reqUserLogin(dict req,  int nRequestID);

int reqUserLogout(dict req,  int nRequestID);

int reqUserPasswordUpdate(dict req,  int nRequestID);

int reqOrderInsert(dict req,  int nRequestID);

int reqOrderAction(dict req,  int nRequestID);

int reqQryOrder(dict req,  int nRequestID);

int reqQryTradingAccount(dict req,  int nRequestID);

int reqQryInvestor(dict req,  int nRequestID);

int reqQryInstrument(dict req,  int nRequestID);

int reqQryInvestorPositionDetail(dict req,  int nRequestID);

int reqQryInvestorPosition(dict req,  int nRequestID);

int reqMBLQuot(dict req,  int nRequestID);

